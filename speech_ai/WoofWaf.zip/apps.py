from django.apps import AppConfig


class WoofwafConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'WoofWaf'
