$(document).ready(function () {
    $('#ddd').DataTable();
});