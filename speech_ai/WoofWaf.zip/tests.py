from WoofWaf.models import pass_log, ip_list, defend_log
from WoofWaf.waf_utils.get_defend_log import get_defend_log

if __name__ == "__main__":
    get_defend_log('127.0.0.1')