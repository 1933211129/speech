import configparser


# https://docs.python.org/zh-cn/3/library/configparser.html
GC="WoofWaf/GeneralConfig/gc.ini"










if __name__ == "__main__":

    # createconfRCR()
    # config = configparser.ConfigParser()
    # config.read('RequestCheckRule.ini')
    # print(config.sections())
    # # delConfig('RequestCheckRule.ini','sqli123')
    # print(config['sqli123']['status']+config['sqli1']['chkurl'])
    # resetField('RequestCheckRule.ini','sqli123','chkheader','0')
    # for i in range(101):
    #     swtichStatus('RequestCheckRule.ini','sqli123','status')
    pass