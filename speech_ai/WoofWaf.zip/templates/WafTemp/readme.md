### 为什么要在templates文件夹下创建文件夹


html文件索引会优先选择先注册的app的templates

创建文件夹后通过 WafTemplates/layout.html索引
