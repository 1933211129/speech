from django.db import models

# Create your models here.

# 赛事申请表(暂且不用)
class SpeechContestApplication(models.Model):
    applicant_name = models.CharField(max_length=30)   # 申请者姓名
    applicant_mobile = models.CharField(max_length=11)     # 申请者手机
    applicant_email = models.CharField(max_length=50)      # 申请者邮箱
    organization = models.CharField(max_length=50)         # 申请者单位
    speech_content = models.CharField(max_length=4000, blank=True, null=True)
    speech_file = models.FileField(upload_to='speech_files/', blank=True, null=True)


        # Add the flag field
    flag = models.BooleanField(default=False)


# 视频展示表
class Video(models.Model):
    title = models.CharField(max_length=255)
    video_path = models.CharField(max_length=255)
    frame_path = models.CharField(max_length=255)
    def __str__(self):
        return f"{self.speaker_name} - {self.speech_topic}"


# 选手参加赛事表
# 【】

# 演讲赛事表
class Competition(models.Model):
    race_id = models.CharField(max_length=30,primary_key=True)
    race_time = models.DateTimeField()
    race_organizers = models.CharField(max_length=100)
    race_location = models.CharField(max_length=200)
    race_rules = models.TextField()
    materials_required = models.CharField(max_length=200)

    def __str__(self):
        return f'Competition {self.race_id} at {self.event_location} on {self.race_time}'

