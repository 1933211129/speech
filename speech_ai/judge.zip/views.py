from django.shortcuts import render
from .models import SpeechContestApplication
from django.shortcuts import redirect
from .models import Video
from moviepy.video.io.VideoFileClip import VideoFileClip
import os



def Competition_application(request):
    return render(request, '../templates/judge/Competition_application.html')

def homepage(request):
    return render(request, '../templates/judge/homepage.html')

def signup(request):
    return render(request, '../templates/judge/SignUp.html')

def contact(request):
    return render(request, '../templates/judge/contact.html')

def index(request):
    videos = Video.objects.all()
    context = {
        'videos': videos
    }
    return render(request, '../templates/judge/index.html', context)




# 传入视频路径，随机截取帧画面
def extract_frame(video_path):
    
    import cv2
    import os
    import random

    # Read the video
    cap = cv2.VideoCapture(video_path)

    # Get a random frame
    cap.set(cv2.CAP_PROP_POS_AVI_RATIO, 1)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    random_frame_index = int(total_frames * random.random())
    cap.set(cv2.CAP_PROP_POS_FRAMES, random_frame_index)
    ret, frame = cap.read()

    # Resize the frame to 320x320
    resized_frame = cv2.resize(frame, (320, 320))

    # Get the video name without extension
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    # Save the frame as a JPEG file with the same name as the video in the same directory
    # frame_path = './speech/frame/'+ video_name + '.jpg'
    frame_path = os.path.join(os.path.dirname(video_path) + '/frame/' + video_name + '.jpg')
    cv2.imwrite(frame_path, resized_frame)

    # Release the video capture
    cap.release()
    return frame_path



# 调取视频和帧画面显示在评委评分页面
def video_index(request):
    videos = Video.objects.all()
    video_properties = []

    for video in videos:
        video_path = video.video_path
        video_title = video.title
        video_frame = video.frame_path
        video_properties.append({
            'title': video_title,
            'path': video_path,
            'thumbnail': video_frame,
        })
    context = {'video_properties': video_properties}
    return render(request, '../templates/judge/judge_video.html', context)




# “火热进行”页面表格
from .models import Competition
from datetime import datetime

def show_events(request):
    # Get all competitions whose race time is after today's date
    events = Competition.objects.filter(race_time__gt=datetime.now())

    # Render the HTML template and pass the events as context
    return render(request, '../templates/judge/event_list.html', {'events': events})

